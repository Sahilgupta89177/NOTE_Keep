package com.example.note_app_gdsc

import android.app.Application


class NoteApplication:Application() {


}